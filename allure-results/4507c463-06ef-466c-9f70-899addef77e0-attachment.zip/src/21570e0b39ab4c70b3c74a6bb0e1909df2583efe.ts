import { test, expect, request } from "@playwright/test";

test("EVENT-Storage State", async () => {
  const apicontext = await request.newContext(); //instead of request fixture here we are using request.newContext();

  const response = await apicontext.post(
    "https://api.eventhub.rahulshettyacademy.com/api/auth/login",
    {
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        email: "trends.06208@gmail.com",
        password: "Trensa@06208",
      },
    },
  );

  console.log(response);

  await apicontext.storageState({ path: "auth-venkat.json" });
  const body = await response.json();
  console.log("=== body response ===\n", body);
  //token = header.payload.signature // JWT - Jason Web Token
  //JWT (JSON Web Token) is a compact, secure way to transmit information between parties as a JSON object. It is commonly used for authentication and authorization in web applications and APIs.

/*Structure of a JWT

A JWT consists of three parts separated by dots (.):

Plain Text
header.payload.signature */

  await apicontext.dispose(); // for api there is no close method, only dispose is available
});