import {test, expect} from '@playwright/test';


test("get method", async({request}) => {
    // const getResponse = await request.get("/booking");
    const getResponse = await request.get("https://restful-booker.herokuapp.com/booking");
    console.log(getResponse);

    const getBodyResponseonly = await getResponse.json();
    console.log(getBodyResponseonly);

    expect(getResponse.status()).toBe(200);
    expect(getResponse.statusText()).toBe("OK")
    await expect(getResponse).toBeOK() // assertion response validation
    expect(getResponse.ok()).toBeTruthy

    expect(getBodyResponseonly.length).toBeGreaterThan(0);
    expect(getBodyResponseonly[3]).toHaveProperty("bookingid");

    expect(typeof getBodyResponseonly[3].toBe("object"));
    expect(typeof getBodyResponseonly[2].bookingid).toBe("number");
})