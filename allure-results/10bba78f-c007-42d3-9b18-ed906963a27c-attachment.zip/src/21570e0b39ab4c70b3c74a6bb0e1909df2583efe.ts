import { test, expect, request } from "@playwright/test";

test("EVENT-Storage State", async () => {
  const apicontext = await request.newContext(); //instead of request fixture here we are using request.newContext();

  const response = await apicontext.post(
    "https://api.eventhub.rahulshettyacademy.com/api/auth/login",
    {
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        email: "trends.06208@gmail.com",
        password: "Trensa@06208",
      },
    },
  );

  console.log(response);

  await apicontext.storageState({ path: "auth-venkat.json" });
  const body = await response.json();
  console.log(`=== body === ${body}`);

  await apicontext.dispose(); // for api there is no close method, only dispose is available
});