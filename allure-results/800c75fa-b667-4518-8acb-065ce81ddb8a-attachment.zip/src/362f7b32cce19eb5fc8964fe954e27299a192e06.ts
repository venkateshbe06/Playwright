import {test} from '@playwright/test';
import {LoginPage} from '../Pageclass/loginPage';
import {ShopPage} from '../Pageclass/shopPage';
import tdata from '../testData/data.json';
// import { Mytest } from '../Fixture/loginfixture';
import { Mytest } from '../My_Fixture/loginfixture';

test("rahulshettyacademy_login", async({page}) => {
    const loginobj = new LoginPage(page);
    await loginobj.navigate(tdata.Url);
    await loginobj.enter_username(tdata.UN);
    await loginobj.enter_password(tdata.pwd);
    await loginobj.check_Terms();
    await loginobj.loginBtn_Click();
    await loginobj.loginValidate();
    await page.waitForTimeout(3000);
})

// need to update
test("rahulshettyacademy_shop", async({page}) => {
    const loginobj = new LoginPage(page);
    await loginobj.navigate(tdata.Url);
    await loginobj.enter_username(tdata.UN);
    await loginobj.enter_password(tdata.pwd);
    await loginobj.check_Terms();
    await loginobj.loginBtn_Click();
    await loginobj.loginValidate();
    await page.waitForTimeout(3000);
    
    const shopobj = new ShopPage(page);
    await shopobj.add_to_cart;
    await shopobj.checkout_blue_btn;
    await shopobj.checkout_green_btn;
    await shopobj.enter_country;
    await shopobj.checkbox_terms_and_conditions;
    await shopobj.checkout_green_btn.click;
    await shopobj.order_message;
    await page.waitForTimeout(3000);
})


// fixtures for login scenario for all testcases - need to add
Mytest("Product Validate using custom fixture", async({loginFix}) => {
    // const loginobj = new LoginPage(page);

    const shopobj = new ShopPage(loginFix);
    await shopobj;
})

//need to update fixture testcase  and full step testcase