import {test} from '@playwright/test';
import {LoginPage} from '../Pageclass/loginPage';
import {ShopPage} from '../Pageclass/shopPage';
import tdata from '../testData/data.json';
// import { Mytest } from '../Fixture/loginfixture';

test("rahulshettyacademy", async({page}) => {
    const loginobj = new LoginPage(page);
    await loginobj.navigate(tdata.Url);
    await loginobj.enter_username(tdata.UN);
    await loginobj.enter_password(tdata.pwd);
    await loginobj.check_Terms();
    await loginobj.loginBtn_Click();
    await loginobj.loginValidate();
})

