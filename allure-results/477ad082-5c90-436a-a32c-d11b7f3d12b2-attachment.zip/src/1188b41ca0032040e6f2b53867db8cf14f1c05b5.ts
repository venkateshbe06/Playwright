import { test } from "@playwright/test";

test.use({ storageState: "AuthNew.json" });

test("click My Booking", async ({ page }) => {
  await page.goto("https://eventhub.rahulshettyacademy.com/");
  await page.getByTestId("nav-bookings").click();
});