import {test, expect} from '@playwright/test';


test("get method", async({request}) => {
    
    // const getResponse = await request.get("https://restful-booker.herokuapp.com/booking");
    const getResponse = await request.get("/booking");
    console.log(getResponse);

    const getBodyResponseonly = await getResponse.json();
    console.log(getBodyResponseonly);

    expect(getResponse.status()).toBe(200);
    expect(getResponse.statusText()).toBe("OK")
    await expect(getResponse).toBeOK() // assertion response validation
    expect(getResponse.ok()).toBeTruthy

    expect(getBodyResponseonly.length).toBeGreaterThan(0);
    expect(getBodyResponseonly[3]).toHaveProperty("bookingid");

    expect(typeof getBodyResponseonly[3]).toBe("object");
    expect(typeof getBodyResponseonly[2].bookingid).toBe("number");
})

test("post method", async({request}) => {
    const start = Date.now();

    const postresponse = await request.post("/booking",{
    headers : {"Content-Type":"application/json"},
    data : {
    "firstname" : "Venkatesh",
    "lastname" : "N",
    "totalprice" : 111,
    "depositpaid" : true,
    "bookingdates" : {
        "checkin" : "2018-01-01",
        "checkout" : "2019-01-01"
    },
    "additionalneeds" : "Breakfast"
    }
}); 

const end = Date.now()
const responseTime = end - start;
const postpayload = await postresponse.json(); // to retrieve body content
console.log(postpayload);
console.log(postresponse.status()) // from raw data

//validation code
expect(postresponse.status()).toBe(200);
expect(postresponse.statusText()).toBe("OK");

//response time
expect.soft(responseTime).toBeLessThan(2000);

//Body Validation

expect(postpayload.bookingid).toBeDefined();
expect(typeof postpayload.bookingid).toBe("number");
expect(typeof postpayload.booking).toBe("object");
expect(postpayload.booking.firstname).toBe("Venkatesh");
expect(postpayload.booking.bookingdates.checkin).toBe("2018-01-01");

//header validation

console.log(postresponse.headers());
const header_array = postresponse.headersArray();

console.log(header_array);
expect(header_array[1]["name"]).toBe("Content-Type");

const header_obj = postresponse.headers();
await expect(header_obj['content-type']).toContain("applicaiton/json");

})